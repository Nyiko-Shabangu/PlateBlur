package com.example.kotlintodopractice.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.example.kotlintodopractice.R
import com.example.kotlintodopractice.databinding.FragmentSettingsBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    private lateinit var navController: NavController
    private lateinit var mAuth: FirebaseAuth
    private lateinit var database: FirebaseDatabase

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        navController = Navigation.findNavController(view)
        mAuth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()

        // Load current settings
        loadSettings()

        // Set up save button click listener
        binding.saveButton.setOnClickListener {
            saveSettings()
        }

        binding.backButton.setOnClickListener {
            navController.navigate(R.id.action_settingsFragment_to_homeFragment)
        }


    }

    private fun loadSettings() {
        // TODO: Implement loading settings from Firebase
        val userId = mAuth.currentUser?.uid
        if (userId != null) {
            val userRef = database.getReference("users").child(userId)
            userRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    // TODO: Parse the snapshot and update UI
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("SettingsFragment", "Failed to read user data", error.toException())
                }
            })
        }
    }

    private fun saveSettings() {
        // TODO: Implement saving settings to Firebase

        /*
        val userId = mAuth.currentUser?.uid
        if (userId != null) {
            val userRef = database.getReference("users").child(userId)
            // TODO: Gather settings from UI and save to Firebase
            userRef.updateChildren(/* your settings map */)
                .addOnSuccessListener {
                    Toast.makeText(context, "Settings saved", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Log.e("SettingsFragment", "Failed to save settings", e)
                    Toast.makeText(context, "Failed to save settings", Toast.LENGTH_SHORT).show()
                }
        }

        */

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}