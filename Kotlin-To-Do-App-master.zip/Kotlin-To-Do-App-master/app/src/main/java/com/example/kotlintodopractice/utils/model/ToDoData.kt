package com.example.kotlintodopractice.utils.model

data class ToDoData(var taskId:String, var task:String,val taskDate: String, val minValue: Int, val maxValue: Int)
