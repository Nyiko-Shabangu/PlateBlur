package com.example.kotlintodopractice.fragments

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kotlintodopractice.databinding.FragmentHomeBinding
import com.example.kotlintodopractice.utils.adapter.TaskAdapter
import com.example.kotlintodopractice.utils.model.ToDoData
import com.example.kotlintodopractice.R
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.*
import androidx.navigation.NavController
import androidx.navigation.Navigation

class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding
    private lateinit var taskAdapter: TaskAdapter
    private val tasks = mutableListOf<ToDoData>()
    private lateinit var navController: NavController

    companion object {
        private const val CAMERA_PERMISSION_CODE = 101
        private const val CAMERA_REQUEST_CODE = 102
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        navController = Navigation.findNavController(view)

        binding.mainRecyclerView.layoutManager = LinearLayoutManager(context)
        taskAdapter = TaskAdapter(tasks)
        binding.mainRecyclerView.adapter = taskAdapter

        binding.addTaskBtn.setOnClickListener {
            showAddTaskDialog()
        }

        binding.settingsButton.setOnClickListener {
            navController.navigate(R.id.action_homeFragment_to_settingsFragment)
        }

        loadTasks()
    }

    private fun loadTasks() {
        tasks.add(ToDoData("Water Plants", "Gardening", "2024-05-01", 2, 4))
        tasks.add(ToDoData("Mow lawn", "Gardening", "2024-05-03", 1, 3))
        tasks.add(ToDoData("Make dinner", "Cooking", "2024-05-05", 3, 5))
        tasks.add(ToDoData("Make lunch", "Cooking", "2024-05-08", 3, 5))
        taskAdapter.notifyDataSetChanged()
    }

    private fun showAddTaskDialog() {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_task, null)

        val taskNameEditText = dialogView.findViewById<EditText>(R.id.taskCategoryEditText)
        val taskDescriptionEditText = dialogView.findViewById<EditText>(R.id.taskEntryEditText)
        val taskPhotoImageView = dialogView.findViewById<ImageView>(R.id.taskPhotoImageView)
        val taskDateEditText = dialogView.findViewById<EditText>(R.id.taskDateEditText)
        val selectDateButton = dialogView.findViewById<Button>(R.id.selectDateButton)
        val minValueEditText = dialogView.findViewById<EditText>(R.id.minValueEditText)
        val maxValueEditText = dialogView.findViewById<EditText>(R.id.maxValueEditText)

        taskPhotoImageView.setOnClickListener {
            checkCameraPermission()
        }

        val dialogBuilder = AlertDialog.Builder(requireContext())
            .setView(dialogView)
            .setTitle("Add New Task")
            .setPositiveButton("Add") { dialog, _ ->
                val taskName = taskNameEditText.text.toString().trim()
                val taskDescription = taskDescriptionEditText.text.toString().trim()
                val taskDate = taskDateEditText.text.toString().trim()
                val minValue = minValueEditText.text.toString().toIntOrNull() ?: 0
                val maxValue = maxValueEditText.text.toString().toIntOrNull() ?: 0

                if (taskName.isNotEmpty()) {
                    val newTask = ToDoData(taskName, taskDescription, taskDate, minValue, maxValue)
                    tasks.add(newTask)
                    taskAdapter.notifyDataSetChanged()
                    dialog.dismiss()
                } else {
                    Toast.makeText(requireContext(), "Task name cannot be empty", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }

        val alertDialog = dialogBuilder.create()
        alertDialog.show()

        selectDateButton.setOnClickListener {
            showDatePickerDialog(taskDateEditText)
        }
    }

    private fun updateMaxValues() {
        val maxValuesMap = mutableMapOf<String, Int>()
        for (task in tasks) {
            val taskId = task.task
            val maxValue = task.maxValue
            maxValuesMap[taskId] = (maxValuesMap[taskId] ?: 0) + maxValue
        }

        val stringBuilder = StringBuilder()
        for ((taskId, maxValue) in maxValuesMap) {
            stringBuilder.append("$taskId - $maxValue hours\n")
        }

        binding.summedMaxValuesTextView.text = stringBuilder.toString()
        taskAdapter.clearTasks()
    }

    private fun showDatePickerForMinDate() {
        val currentDate = Calendar.getInstance()
        val year = currentDate.get(Calendar.YEAR)
        val month = currentDate.get(Calendar.MONTH)
        val day = currentDate.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(requireContext(), { _, year, month, dayOfMonth ->
            val selectedMinDate = formatDate(year, month, dayOfMonth)
            showDatePickerForMaxDate(selectedMinDate)
        }, year, month, day).show()
    }

    private fun showDatePickerForMaxDate(minDate: String) {
        val currentDate = Calendar.getInstance()
        val year = currentDate.get(Calendar.YEAR)
        val month = currentDate.get(Calendar.MONTH)
        val day = currentDate.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(requireContext(), { _, year, month, dayOfMonth ->
            val selectedMaxDate = formatDate(year, month, dayOfMonth)
            performSearch(minDate, selectedMaxDate)
        }, year, month, day).show()
    }

    private fun formatDate(year: Int, month: Int, day: Int): String {
        val calendar = Calendar.getInstance()
        calendar.set(year, month, day)
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return dateFormat.format(calendar.time)
    }

    private fun performSearch(minDate: String, maxDate: String) {
        val filteredTasks = tasks.filter { task ->
            task.taskDate in minDate..maxDate
        }

        if (filteredTasks.isNotEmpty()) {
            taskAdapter.updateTasks(filteredTasks)
            showGraphDialog(filteredTasks)
        } else {
            Toast.makeText(requireContext(), "No tasks found for the selected dates", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showGraphDialog(filteredTasks: List<ToDoData>) {
        val graphDialog = GraphDialogFragment(filteredTasks)
        graphDialog.show(childFragmentManager, "GraphDialog")
    }

    private fun showDatePickerDialog(editText: EditText) {
        val datePickerDialog = DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                val calendar = Calendar.getInstance()
                calendar.set(year, month, dayOfMonth)
                val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                val selectedDate = dateFormat.format(calendar.time)
                editText.setText(selectedDate)
            },
            Calendar.getInstance().get(Calendar.YEAR),
            Calendar.getInstance().get(Calendar.MONTH),
            Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.show()
    }

    private fun checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(Manifest.permission.CAMERA),
                CAMERA_PERMISSION_CODE
            )
        } else {
            openCamera()
        }
    }

    private fun openCamera() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera()
            } else {
                Toast.makeText(requireContext(), "Camera permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val photoBitmap = data?.extras?.get("data") as Bitmap
        }
    }
}
